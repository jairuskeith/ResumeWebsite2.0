package com.example.jkandroid.jk_project6;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

public class DrawView extends View implements View.OnTouchListener {

    //Bitmaps for the landscape
    Bitmap mountain = BitmapFactory.decodeResource(getResources(), R.drawable.mountain);//assign your bitmap;
    Bitmap forest = BitmapFactory.decodeResource(getResources(), R.drawable.forest);//assign your bitmap;
    Bitmap plain = BitmapFactory.decodeResource(getResources(), R.drawable.plain);//assign your bitmap;
    Bitmap water = BitmapFactory.decodeResource(getResources(), R.drawable.water);//assign your bitmap;
    Bitmap treasure = BitmapFactory.decodeResource(getResources(), R.drawable.treasure);//assign your bitmap;
    Bitmap out = BitmapFactory.decodeResource(getResources(), R.drawable.out);//assign your bitmap;

    //Bitmaps for the characters
    Bitmap person = BitmapFactory.decodeResource(getResources(), R.drawable.person);
    Bitmap enemy1 = BitmapFactory.decodeResource(getResources(), R.drawable.enemy1);
    Bitmap enemy2 = BitmapFactory.decodeResource(getResources(), R.drawable.enemy2);
    Bitmap enemy3 = BitmapFactory.decodeResource(getResources(), R.drawable.enemy3);
    Bitmap enemy4 = BitmapFactory.decodeResource(getResources(), R.drawable.enemy4);

    //Bitmap letters
    Bitmap w = BitmapFactory.decodeResource(getResources(), R.drawable.w);//assign your bitmap;
    Bitmap o = BitmapFactory.decodeResource(getResources(), R.drawable.o);//assign your bitmap;
    Bitmap n = BitmapFactory.decodeResource(getResources(), R.drawable.n);//assign your bitmap;
    Bitmap y = BitmapFactory.decodeResource(getResources(), R.drawable.y);//assign your bitmap;
    Bitmap u = BitmapFactory.decodeResource(getResources(), R.drawable.u);//assign your bitmap;
    Bitmap l = BitmapFactory.decodeResource(getResources(), R.drawable.l);//assign your bitmap;
    Bitmap s = BitmapFactory.decodeResource(getResources(), R.drawable.s);//assign your bitmap;
    Bitmap t = BitmapFactory.decodeResource(getResources(), R.drawable.t);//assign your bitmap;

    Bitmap[][] arrayOfBitmap = {
            {out, out, out, out, out, out, out, out, out, out, out},
            {out, mountain, mountain, mountain, mountain, forest, forest, forest, forest, out, out},
            {out, mountain, mountain, mountain, forest, forest, forest, forest, forest, out},
            {out, mountain, mountain, forest, plain, plain, plain, forest, forest, out},
            {out, mountain, forest, plain, plain, plain, plain, plain, plain, out},
            {out, water, plain, plain, plain, plain, plain, plain, plain, out},
            {out, water, water, plain, plain, plain, plain, plain, plain, out},
            {out, water, water, water, water, treasure, plain, plain, plain, out},
            {out, water, plain, water, water, plain, plain, plain, plain, out},
            {out, water, plain, plain, water, plain, plain, plain, plain, out},
            {out, water, water, water, water, plain, plain, plain, mountain, out},
            {out, water, water, water, water, plain, plain, mountain, mountain, out},
            {out, out, out, out, out, out, out, out, out, out},
            {out, out, out, out, out, out, out, out, out, out}
    };

    float nextX, nextY, finalY, finalX, clickedX, clickedY, canvasX, canvasY, leftScroll, topScroll,
          randomNum1, randomNum2, randomNum3, randomNum4, randomNum5, randomNum6, randomNum7, randomNum8;

    //Random number generators for enemies
    Random random = new Random();

    int width, height, clickedWidth, clickedHeight;

    boolean won = false;
    boolean lost = false;

    //Creates the scrolling effect
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        //Changes the size of the canvas
        width = 2000;
        height = 2000;

        //The variables for the imaginary perimeter
        clickedWidth = 2000;
        clickedHeight = 2000;
        setMeasuredDimension(width, height);
    }

    public DrawView(Context context) {
        super(context);
        setup();
    }

    public DrawView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setup();
    }

    private void setup() {
        //Variables for current position
        nextX = 150.0f;
        nextY = 150.0f;

        //Variables for starting position
        finalX = 50f;
        finalY = 50f;

        //Variables for how far the screen scrolls
        leftScroll = 150;
        topScroll = 150;
        setOnTouchListener(this);
    }

    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {

            //Variables for debugging
            clickedX = event.getX();
            clickedY = event.getY();

                //This changes the person coordinates
                //Controls the persons X coordinate
                if(clickedX > (clickedWidth - 1200)) {
                    nextX = nextX + 150;
                }
                if(clickedX < (clickedWidth - 1750)) {
                    nextX = nextX -150;
                }

                //Controls the persons Y coordinate
                if (clickedY > (clickedHeight - 800)) {
                    nextY = nextY + 150;
                }
                if(clickedY < (clickedHeight - 1800)) {
                    nextY = nextY -150;
                }

            //This changes the origin of the canvas when person reaches the X coordinate edges
            if(nextX > (width - 1200)) {
                width += 150;
                canvasX += -150;
                leftScroll += 150;
            } else if(nextX < leftScroll) {
                width += -150;
                canvasX += 150;
                leftScroll += -150;
            }

            //This changes the origin of the canvas when person reaches the y coordinate edges
            if(nextY > (height - 1200)) {
                height += 150;
                canvasY += -150;
                topScroll += 150;
            } else if(nextY < topScroll) {
                height += -150;
                canvasY += 150;
                topScroll += -150;
            }

            //The random numbers generated for the enemies
            randomNum1 = random.nextInt(650 - 150) + 150;
            randomNum2 = random.nextInt(650 - 150) + 150;
            randomNum3 = random.nextInt(900 - 600) + 600;
            randomNum4 = random.nextInt(1200 - 900) + 900;
            randomNum5 = random.nextInt(1200 - 150) + 150;
            randomNum6 = random.nextInt(1650 - 150) + 150;
            randomNum7 = random.nextInt((int) (nextX - (nextX - 300))) + (nextX - 300);
            randomNum8 = random.nextInt((int) (nextY - (nextY - 300))) + (nextY - 300);

            //Restarts the game if the player loses and click again
            if(lost || won) {
                nextX = 150;
                nextY = 150;
                leftScroll = 150;
                topScroll = 150;
                canvasX = 0;
                canvasY = 0;

                //Restores the size of the canvas
                width = 2000;
                height = 2000;

                //The variables for the imaginary perimeter
                clickedWidth = 2000;
                clickedHeight = 2000;
            }

            //Checks if person is above treasure bitmap
            won = (nextY >= 950 && nextY <= 1150) && (nextX >= 700 && nextX <= 800);

            //Checks if the player went out of bounds or hit an enemy
            lost = ((nextY >= 1800) || (nextY <= 0) || (nextX >= 1350) || (nextX <= 0)) //Out of bounds
            || (nextX >= (randomNum1 - 100) && (nextX <= (randomNum1 + 100)) && nextY >= (randomNum2 - 100) && (nextY <= (randomNum2 + 100))) //Enemy1 coordinates
            || (nextX >= (randomNum3 - 100) && (nextX <= (randomNum3 + 100)) && nextY >= (randomNum4 - 100) && (nextY <= (randomNum4 + 100))) //Enemy2 coordinates
            || (nextX >= (randomNum5 - 100) && (nextX <= (randomNum5 + 100)) && nextY >= (randomNum6 - 100) && (nextY <= (randomNum6 + 100))) //Enemy3 coordinates
            || (nextX >= (randomNum7 - 100) && (nextX <= (randomNum7 + 100)) && nextY >= (randomNum8 - 100) && (nextY <= (randomNum8 + 100))); //Enemy4 coordinates


            if(won) {

                arrayOfBitmap = new Bitmap[][]{
                        {out, out, out, out, out, out, out, out, out, out, out},
                        {out, mountain, mountain, mountain, mountain, forest, forest, forest, forest, out, out},
                        {out, mountain, mountain, mountain, forest, forest, forest, forest, forest, out},
                        {out, mountain, mountain, forest, plain, plain, plain, forest, forest, out},
                        {out, mountain, forest, plain, plain, plain, plain, plain, plain, out},
                        {out, water, plain, plain, y, o, u, plain, plain, out},
                        {out, water, water, plain, w, o, n, plain, plain, out},
                        {out, water, water, water, water, treasure, plain, plain, plain, out},
                        {out, water, plain, water, water, plain, plain, plain, plain, out},
                        {out, water, plain, plain, water, plain, plain, plain, plain, out},
                        {out, water, water, water, water, plain, plain, plain, mountain, out},
                        {out, water, water, water, water, plain, plain, mountain, mountain, out},
                        {out, out, out, out, out, out, out, out, out, out},
                        {out, out, out, out, out, out, out, out, out, out}
                };
            } else if(lost) {

                arrayOfBitmap = new Bitmap[][]{
                        {out, out, out, out, out, out, out, out, out, out, out},
                        {out, mountain, mountain, mountain, mountain, forest, forest, forest, forest, out, out},
                        {out, mountain, mountain, mountain, forest, forest, forest, forest, forest, out},
                        {out, mountain, mountain, forest, plain, plain, plain, forest, forest, out},
                        {out, mountain, forest, plain, plain, plain, plain, plain, plain, out},
                        {out, water, plain, plain, y, o, u, plain, plain, out},
                        {out, water, water, plain, l, o, s, t, plain, out},
                        {out, water, water, water, water, treasure, plain, plain, plain, out},
                        {out, water, plain, water, water, plain, plain, plain, plain, out},
                        {out, water, plain, plain, water, plain, plain, plain, plain, out},
                        {out, water, water, water, water, plain, plain, plain, mountain, out},
                        {out, water, water, water, water, plain, plain, mountain, mountain, out},
                        {out, out, out, out, out, out, out, out, out, out},
                        {out, out, out, out, out, out, out, out, out, out}
                };
            } else {

                arrayOfBitmap = new Bitmap[][]{
                        {out, out, out, out, out, out, out, out, out, out, out},
                        {out, mountain, mountain, mountain, mountain, forest, forest, forest, forest, out, out},
                        {out, mountain, mountain, mountain, forest, forest, forest, forest, forest, out},
                        {out, mountain, mountain, forest, plain, plain, plain, forest, forest, out},
                        {out, mountain, forest, plain, plain, plain, plain, plain, plain, out},
                        {out, water, plain, plain, plain, plain, plain, plain, plain, out},
                        {out, water, water, plain, plain, plain, plain, plain, plain, out},
                        {out, water, water, water, water, treasure, plain, plain, plain, out},
                        {out, water, plain, water, water, plain, plain, plain, plain, out},
                        {out, water, plain, plain, water, plain, plain, plain, plain, out},
                        {out, water, water, water, water, plain, plain, plain, mountain, out},
                        {out, water, water, water, water, plain, plain, mountain, mountain, out},
                        {out, out, out, out, out, out, out, out, out, out},
                        {out, out, out, out, out, out, out, out, out, out}
                };
            }

            //Debugging game state booleans
            Log.i("------------------", "------------------------");
            Log.i("GAME_STATE:", "WON:" + won + ", LOST:" + lost);
            Log.i("IMAGINARY_COORDINATES:", "X:" + clickedWidth + ", Y:" + clickedHeight);
            Log.i("CANVAS_COORDINATES:", "X:" + width + ", Y:" + height);
            Log.i("CLICKED_COORDINATES:", "X:" + event.getX() + ", Y:" + event.getY());
            Log.i("PERSON_COORDINATES:", "X:" + nextX + ", Y:" + nextY);
            Log.i("ENEMY1_COORDINATES:", "X:" + randomNum1 + ", Y:" + randomNum2);
            Log.i("ENEMY2_COORDINATES:", "X:" + randomNum2 + ", Y:" + randomNum1);
            invalidate();
        }
        return true;
    }

    public void onDraw(final Canvas canvas) {

        canvas.save();
        canvas.translate(canvasX, canvasY);

        float x = 0;
        float y = 0;

        //Finds the array within the array (ROW)
        for (int i = 0; i < 14; i++) {
            //Finds the element in the array (COLUMN)
            for (int j = 0; j < 10; j++) {

                canvas.drawBitmap(arrayOfBitmap[i][j], x, y, null);
                x = x + 150f;
            }
            x = 0;
            y = y + 150f;
        }

        //Draws the character on the bitmap and new coordinates
        canvas.drawBitmap(person, nextX, nextY, null);

        //Draws enemy1
        canvas.drawBitmap(enemy1, randomNum1, randomNum2, null); //red

        //Draws enemy3
        canvas.drawBitmap(enemy3, randomNum3, randomNum4, null); //orange

        //Draws enemy2
        canvas.drawBitmap(enemy2, randomNum5, randomNum6, null); //green

        //Draws enemy4
        canvas.drawBitmap(enemy4, randomNum7, randomNum8, null); //black
        canvas.restore();
    }
}